import numpy as np

#Exercise 1

"""myArray = np.linspace(0,1,100)
#myArray = [x*10 for x in myArray]
print(myArray)"""

#Exercrise 2

"""myArray = np.array([2, 5, 8, 10, 13, 17, 20])
evenNumbers = myArray[myArray%2 == 0]
print(evenNumbers)"""

#Exercise 3

"""matriceA = np.array([[1,2],[3,4]])

matriceB = np.array([[5,6],[7,8]])

result = np.dot(matriceA,matriceB)

print(result)"""

#Exercise 4

"""myArray = np.array([1, 2, 3, 4, 5, 6, 7, 8])
myMatrice = myArray.reshape(2,4)
print(myMatrice)"""

#Exercise 5

data = np.array([10, 15, 20, 25, 30])
dataMean = np.mean(data)
dataDeviation = np.std(data)
print("Mean: ", dataMean)
print("Standard Deviation: ", dataDeviation)



