#Exercise1
"""def sum_numbers(number1:int,number2:int):
    
        #number1 = first number to be added
        #number2 = second number to be added
        #result = sum of these numbers
    
    result = number1+number2
    return(result)


number1 = 10
number2 = 20

result = sum_numbers(number1,number2)
print(result)
"""

#Exercise2

def find_maximum(mylist:list):
    """
        mylist = the list which we want to find the maximum number
        maximum_value = biggest value of the list called mylist
    """
    maximum_value = max(mylist)
    return (maximum_value)


list1 = [1,2,3,4,5,6,7]

biggest_number = find_maximum(list1)

print(biggest_number)