
myNumbers = [1,2,3,4,5,6,6,2,3,5,4]

myNumbers = list(set(myNumbers))

print(myNumbers)