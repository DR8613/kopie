
var = 10
var2 = "10"

print(type(var),type(var2))


def printVar(var):
    var2 = var
    var4 = var
    print(var4)


printVar(50)




