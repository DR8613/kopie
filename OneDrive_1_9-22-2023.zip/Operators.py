number1 = 10
number2 = 15

result = (number1+number2)*5

myList = [1,2,3,4,5,6,7]

#print(4 in myList)

myString = "My name is Enrique"

#print("My name" in myString)


myAge = 25
templateString = "My age is "

#print(templateString+str(myAge))

print( int(10.9) )
