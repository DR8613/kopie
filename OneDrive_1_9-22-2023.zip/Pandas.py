import pandas as pd

#Exercise 1
"""data = {

    "Fruit": ["Apple","Banana","Cherry"],
    "Quantity" : [5,10,15]

}

df = pd.DataFrame(data)

print(df)"""

#Exercise 2
"""data = {
    "Name":["Alice","Bob","Charlie","David"],
    "Grade":[85,92,88,95]
}

df = pd.DataFrame(data)

filtered_df = df[df["Grade"] >= 90]

print(filtered_df)"""


data = {
    "Product":["A","B","A","B","A"],
    "Category": ["X","Y","X","Y","X"],
    "Revenue": [100,150,120,200,90]
}

df = pd.DataFrame(data)

category = df.groupby("Category")['Revenue'].sum().reset_index

print(category)