"""name = input("Enter your name: ")
print()"""

number1 = 5
number2 = 10

print("My first number: ",number1,"\nMy second number: ",number2)