myVariable = 2

"""if(myVariable > 5):
    print(myVariable)
else:
    print(" FUCTION 1: Value is not bigger than 5")"""

#=========================================

if(myVariable > 10):
    print(" FUCTION 2: bigger than 10")
elif(myVariable > 5):
    print(" FUCTION 2: bigger than 5")
elif(myVariable >= 2):
    print("FUCTION 2: equal or bigger than 2")