
"""path = "C:/Users/BE611ST/OneDrive - EY/Desktop/Python/Codes/Files/"
file_name = "example.txt"
file = open(path+file_name,"w")

for file_lines in range(50): 
   file.write(str(file_lines)+"\n")
file.close()


file = open(path+file_name,"r")
#content = file.read()
content = file.readlines()
"""


path = "C:/Users/BE611ST/OneDrive - EY/Desktop/Python/Codes/Files/"
file_name = "output.txt"

user_input = input("WRITE YOUR SENTENCE: ")
user_input = user_input + "\n"

file = open(path+file_name,"a")
file.write(user_input)
file.close()