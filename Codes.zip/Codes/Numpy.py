import numpy as np

matrice = [[0,1,2],
           [3,"number",5],
           [6,7,8]]

numpy_matrice = np.array([[0,1,2],[3,"number",4],[6,7,8]])

print(type(matrice))

print(numpy_matrice)