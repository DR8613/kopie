"""
Students = {
    "NameStudent1":"Miguel",
    "GradeStudent1": 3,
    "NameStudent2":"Barbara",
    "GradeStudent2": 3,
    "NameStudent3":"Miguel",
    "GradeStudent3": 3,
}
"""

#listOfStudents = [{'Name': 'Miguel', 'Grade': 5}, {'Name': 'Barbara', 'Grade': 5}, {'Name': 'Marcos', 'Grade': 3}]

listOfStudent = []
average = 0

numberOfStudents = input("How many students you want to register?: ")

for n in range(int(numberOfStudents)):
    studentName = input("Write the student name: ")
    studentGrade = input("Write the student grade: ")
    studentDictionary = {
        "Name":studentName,
        "Grade": int(studentGrade)
    }
    listOfStudent.append(studentDictionary)
    print("\n")

print(listOfStudent)


for x in listOfStudent:
    average += x["Grade"]
print(average/len(listOfStudent))


















