myVariable = [1,2,4,4,5]
print(type(myVariable))


"""
Use the print command  and type command to check the data type of the following values:

1 - 35
2 - “my variable in Python”
3 - [1,2,4,4,5]
4 - {1,2,3,4,6}

"""