def square(number1:int):
    """
        number1 = first number to be added
        number2 = second number to be added
        sum = the variable which stores the result of the sum
        return = return the sum of the numbers
    """
    square = number1*number1
    return(square)

squareOfNumber = square(5)
print(squareOfNumber)