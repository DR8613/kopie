my_list = [1,2,4,5,6,8,10,11,11,2,3,5,6,7,8,10,2,1,2,1,2]

#printing the last element 
#print(my_list[-1])
#slicing a list
#print(my_list[1:4])



print(my_list)