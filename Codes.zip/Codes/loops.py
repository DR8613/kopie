
participants = ["kamil","justyna","michal","daniel","magdalena","renata","enrique","marcin"]

for participant in participants:
   print(participant)


for position in range(0,8):
    print(participants[position])


var = 5
rep = 0
while rep < 5:
    print(rep)
    rep += 1