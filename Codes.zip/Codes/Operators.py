
myVariable = input("Insert one number :")
myVariable2 = input("Insert second number: ")
print( myVariable + myVariable2 )
