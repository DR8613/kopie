import re

#dd-mm-yyyy
text = "8LxLRu5#&Wnm!H0XLPf&P*Q[.%PQ6e)902023/12/21iE%*Rtbqn3R%pBM{*F;vzcc]wAuSeDzS8c1VQm%(tt,Jw[,G@RxJpX%-JVb43:ie/Mt(07/08/2023)VC6}G;Fg[;0M5?*T3X!(aFq%]z0MF%6Y0i51}V?1*a_q8x6%mg/+#{$xq{{iKckWPzz+r*8V,w&udwA0_)a4!UEx$$L:5x6g11/08/20235_Y56?mR&H7j=n)[$dhe04hr$Z2b2?n;]-uSzF;=Grgn3Q0aXV=;HP/=P;7Dd9gM1TN]_6Srp3j7fRL15/08/20231pK;&_AjcKbgKqQcafUw+Xt"

#firstSelection = text.split(";")[6][2:12]
#dd/mm/yyyy
#yyy
#pattern = r"\d{2}/\d{2}/\d{4}"
text2 = "1231abc124521"
pattern = r"[a-z]"
matches = re.findall(pattern,text2)
print(matches)
